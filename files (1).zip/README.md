# Modern Data Engineering for Advanced AI Systems - RAG Application

**SDAIA Academy | Modern Data Engineering Capstone Project**

![SDAIA Academy](https://sdaia.gov.sa) | [GitHub Organization](https://github.com/SDAIAAcademy)

#SDAIAAcademy

---

## 📋 Project Overview

This repository contains a **Full Retrieval-Augmented Generation (RAG) Application** built as the capstone project for the SDAIA Academy's "Modern Data Engineering for Advanced AI Systems" program. The project demonstrates an end-to-end enterprise-grade data pipeline integrating modern data engineering principles with AI-powered retrieval and generation capabilities.

### Key Program Reference
**Program:** Modern Data Engineering for Advanced AI Systems  
**Organization:** SDAIA Academy  
**Website:** [https://sdaia.gov.sa](https://sdaia.gov.sa)  
**Project Level:** Advanced Capstone

---

## 🏗️ Architecture Overview

This RAG application implements a production-ready architecture combining the following layers:

### 1. **Data Ingestion & Processing Layer**
- **Kafka-based Streaming**: Confluent Kafka for resilient data streaming
- **Data Validation**: Pydantic-based data contracts and validation
- **Dead-Letter Queue (DLQ)**: Automatic handling of malformed records with logging

### 2. **Storage Layer - Delta Lake**
- **Bronze Layer**: Raw validated ingestion payload (immutable source of truth)
- **Silver Layer**: Schema-enforced, cleaned data with MERGE operations for upserts
- **Gold Layer**: Optimized data for AI/BI consumption

### 3. **Vector Search & Retrieval Layer**
- **Embeddings Generation**: Converting documents to vector representations
- **Vector Store**: Persistent storage of embeddings (FAISS, Weaviate, Pinecone)
- **Hybrid Search**: Combining keyword-based and semantic search
- **Cross-Encoder Reranking**: Advanced reranking for improved retrieval quality

### 4. **Generation & RAG Layer**
- **Document Retrieval**: Fetching relevant context from the knowledge base
- **Prompt Engineering**: Optimized prompts for coherent generation
- **LLM Integration**: Language model for response generation
- **Quality Assurance**: Output validation and quality gates

### 5. **Orchestration & Monitoring**
- **Apache Airflow**: Workflow orchestration and scheduling
- **OpenLineage Telemetry**: Data lineage tracking and observability
- **Quality Gates**: Automated validation at each pipeline stage

---

## 📂 Project Structure

```
rag-application/
├── app/
│   ├── ingestion/
│   │   ├── producer.py          # Kafka producer for data streaming
│   │   ├── broker.py            # Kafka broker configuration
│   │   └── contracts.py         # Pydantic data contracts
│   │
│   ├── quality/
│   │   ├── validation.py        # Quality checks and validation logic
│   │   ├── consumer.py          # Kafka consumer for quality monitoring
│   │   └── dlq_handler.py       # Dead-Letter Queue management
│   │
│   ├── storage/
│   │   ├── delta_lake.py        # Delta Lake Bronze/Silver/Gold layers
│   │   ├── bronze_layer.py      # Raw data storage
│   │   ├── silver_layer.py      # Cleaned, deduplicated data
│   │   └── gold_layer.py        # AI/BI optimized outputs
│   │
│   ├── rag/
│   │   ├── embeddings.py        # Embedding generation
│   │   ├── vector_store.py      # Vector database operations
│   │   ├── retriever.py         # Document retrieval logic
│   │   ├── hybrid_search.py     # Keyword + semantic search
│   │   ├── reranker.py          # Cross-Encoder reranking
│   │   ├── prompt_engine.py     # Prompt templates and engineering
│   │   ├── llm_client.py        # LLM integration (OpenAI, Anthropic, etc.)
│   │   └── matcher.py           # Query-document matching logic
│   │
│   ├── pipeline.py              # Main pipeline orchestration
│   ├── main.py                  # API and application entry point
│   └── config.py                # Configuration management
│
├── dags/
│   ├── data_ingestion_dag.py    # Airflow DAG for ingestion
│   ├── quality_checks_dag.py    # Quality validation DAG
│   ├── rag_pipeline_dag.py      # RAG pipeline DAG
│   └── monitoring_dag.py        # Monitoring and alerting DAG
│
├── data/
│   ├── sample_documents.json    # Sample documents/knowledge base
│   ├── eval/
│   │   ├── test_queries.json    # Test queries for evaluation
│   │   └── ground_truth.json    # Ground truth for RAGAS evaluation
│   └── raw/
│       └── kafka_records/       # Sample Kafka records
│
├── notebooks/
│   ├── 01_data_exploration.ipynb        # EDA and data understanding
│   ├── 02_embedding_analysis.ipynb      # Embedding quality analysis
│   ├── 03_retrieval_evaluation.ipynb    # Retrieval performance metrics
│   └── 04_rag_evaluation.ipynb          # End-to-end RAG evaluation
│
├── tests/
│   ├── test_ingestion.py        # Unit tests for ingestion
│   ├── test_quality.py          # Quality check tests
│   ├── test_storage.py          # Delta Lake operations tests
│   ├── test_rag.py              # RAG component tests
│   └── test_integration.py      # End-to-end integration tests
│
├── config/
│   ├── airflow.yaml             # Airflow configuration
│   ├── kafka.yaml               # Kafka configuration
│   ├── embedding_models.yaml    # Embedding model configs
│   └── llm.yaml                 # LLM provider configurations
│
├── requirements.txt             # Python dependencies
├── requirements-dev.txt         # Development dependencies
├── Dockerfile                   # Docker containerization
├── docker-compose.yml           # Multi-container orchestration
├── .env.example                 # Environment variables template
├── .gitignore                   # Git ignore patterns
├── README.md                    # This file
├── CONTRIBUTING.md              # Contribution guidelines
└── LICENSE                      # Apache 2.0 License
```

---

## 🚀 Getting Started

### Prerequisites
- Python 3.9+
- Docker & Docker Compose
- Kafka cluster (local or remote)
- Vector database (FAISS, Weaviate, or Pinecone)
- LLM API access (OpenAI, Anthropic, or self-hosted)

### Installation

#### 1. Clone the Repository
```bash
git clone https://github.com/yourusername/rag-application.git
cd rag-application
```

#### 2. Create Virtual Environment
```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

#### 3. Install Dependencies
```bash
pip install -r requirements.txt
```

#### 4. Configure Environment Variables
```bash
cp .env.example .env
# Edit .env with your configuration
```

#### 5. Start Infrastructure with Docker Compose
```bash
docker-compose up -d
# This starts Kafka, Zookeeper, and other services
```

---

## 🔄 Pipeline Flow

### Data Flow Diagram
```
Kafka Producer
    ↓
[Ingestion Layer]
    ├── Streaming ingestion via confluent-kafka
    ├── Pydantic validation against data contracts
    └── DLQ routing for invalid records
    ↓
[Quality Layer]
    ├── Data quality checks
    ├── Schema validation
    └── Duplicate detection
    ↓
[Storage Layer - Delta Lake]
    ├── Bronze: Raw data ingestion
    ├── Silver: Cleaned, deduplicated, merged data
    └── Gold: Optimized for AI/BI
    ↓
[Vector Search Layer]
    ├── Document chunking
    ├── Embedding generation
    └── Vector store indexing
    ↓
[RAG Layer]
    ├── Query embedding
    ├── Hybrid search (keyword + semantic)
    ├── Cross-Encoder reranking
    └── Context retrieval
    ↓
[Generation Layer]
    ├── Prompt engineering
    ├── LLM query
    └── Response generation
    ↓
[Output]
    └── Ranked answers with confidence scores
```

---

## 📊 Key Features

### Data Engineering
- ✅ **Kafka Streaming**: Resilient, distributed data ingestion
- ✅ **Data Contracts**: Pydantic-based validation
- ✅ **Delta Lake**: ACID-compliant, time-travel capable storage
- ✅ **Quality Gates**: Automated validation at each stage
- ✅ **Dead-Letter Queue**: Graceful error handling
- ✅ **Schema Evolution**: Handle schema changes safely

### AI/RAG Components
- ✅ **Hybrid Search**: Combine BM25 keyword and vector similarity search
- ✅ **Cross-Encoder Reranking**: Improve retrieval relevance
- ✅ **Multiple Embeddings**: Support for various embedding models
- ✅ **Prompt Optimization**: Engineered prompts for better generation
- ✅ **LLM Flexibility**: Support for multiple LLM providers
- ✅ **RAGAS Evaluation**: Automated RAG quality assessment

### Operations
- ✅ **Apache Airflow**: Orchestration and scheduling
- ✅ **OpenLineage**: Data lineage tracking
- ✅ **Comprehensive Logging**: Structured logging throughout
- ✅ **Monitoring**: Metrics and alerts
- ✅ **Docker**: Containerized deployment
- ✅ **Tests**: Unit and integration tests

---

## 🔧 Configuration

### Kafka Configuration (`config/kafka.yaml`)
```yaml
bootstrap_servers: "localhost:9092"
topic_input: "documents_raw"
topic_dlq: "documents_dlq"
consumer_group: "rag_pipeline"
```

### Embedding Models (`config/embedding_models.yaml`)
```yaml
models:
  - name: "sentence-transformers/all-MiniLM-L6-v2"
    dimension: 384
    provider: "huggingface"
  - name: "text-embedding-3-small"
    dimension: 1536
    provider: "openai"
```

### LLM Configuration (`config/llm.yaml`)
```yaml
provider: "anthropic"  # or "openai", "huggingface"
model: "claude-3-sonnet-20240229"
temperature: 0.7
max_tokens: 1024
```

---

## 🏃 Running the Pipeline

### 1. Start Data Ingestion
```bash
python app/pipeline.py --stage ingestion
```

### 2. Run Quality Checks
```bash
python app/pipeline.py --stage quality
```

### 3. Generate Embeddings
```bash
python app/pipeline.py --stage embeddings
```

### 4. Start RAG API
```bash
python app/main.py
# API available at http://localhost:8000
```

### 5. Query the RAG Application
```bash
curl -X POST http://localhost:8000/query \
  -H "Content-Type: application/json" \
  -d '{"query": "What is modern data engineering?"}'
```

---

## 🧪 Testing

### Run All Tests
```bash
pytest tests/ -v
```

### Run Specific Test Suites
```bash
# Ingestion tests
pytest tests/test_ingestion.py -v

# RAG tests
pytest tests/test_rag.py -v

# Integration tests
pytest tests/test_integration.py -v
```

### Run with Coverage
```bash
pytest tests/ --cov=app --cov-report=html
```

---

## 📈 Evaluation Metrics

### Retrieval Metrics
- **MRR (Mean Reciprocal Rank)**: Position of first relevant document
- **NDCG (Normalized Discounted Cumulative Gain)**: Quality of ranking
- **Recall@K**: Proportion of relevant documents in top K

### RAG Metrics (RAGAS)
- **Faithfulness**: How grounded is the response in retrieved documents
- **Answer Relevance**: How well does the answer address the query
- **Context Relevance**: Quality of retrieved context
- **Overall Score**: Composite RAG quality metric

### Example Evaluation
```bash
python notebooks/04_rag_evaluation.ipynb
```

---

## 🐳 Docker Deployment

### Build Docker Image
```bash
docker build -t rag-application:latest .
```

### Run with Docker Compose
```bash
docker-compose up
```

### Access Services
- RAG API: http://localhost:8000
- Airflow UI: http://localhost:8080
- Kafka UI: http://localhost:8081

---

## 📚 Key Technologies

| Component | Technology | Version |
|-----------|-----------|---------|
| **Data Ingestion** | Apache Kafka | 3.6+ |
| **Storage** | Delta Lake | 3.0+ |
| **Processing** | Apache Spark | 3.4+ |
| **Orchestration** | Apache Airflow | 2.6+ |
| **Vector DB** | FAISS/Weaviate/Pinecone | - |
| **Embeddings** | Sentence Transformers | 2.2+ |
| **LLM** | OpenAI/Anthropic API | - |
| **Web Framework** | FastAPI | 0.100+ |
| **Testing** | pytest | 7.4+ |
| **Containerization** | Docker | 24+ |

---

## 🌟 Day 3 Reference Example

This project extends the foundational concepts from **Day 3** of the SDAIA Academy curriculum:

### Day 3 Topics Implemented
1. **Hybrid Search Architecture**: Combining BM25 and semantic search
2. **Cross-Encoder Reranking**: Two-stage retrieval for quality
3. **Delta Lake Operations**: Real MERGE operations for data quality
4. **Quality Gates**: Automated validation and quarantine
5. **LLM Integration**: Prompt engineering and response generation
6. **End-to-End Pipeline**: From raw data to generated answers

---

## 📝 Submission Guidelines

As per SDAIA Academy requirements:

1. ✅ **Repository Name**: Include "SDAIA" or program reference
2. ✅ **README**: Include program name and SDAIA Academy link
3. ✅ **Hashtag**: Add #SDAIAAcademy in README and commit messages
4. ✅ **Attribution**: Link to [SDAIA Academy GitHub](https://github.com/SDAIAAcademy)
5. ✅ **Code Quality**: Follow PEP 8 and include documentation
6. ✅ **Testing**: Comprehensive test coverage (>80%)
7. ✅ **Evidence**: Supporting notebooks and documentation

---

## 🤝 Contributing

Contributions are welcome! Please see [CONTRIBUTING.md](CONTRIBUTING.md) for guidelines.

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit changes (`git commit -m 'Add amazing feature'`)
4. Push to branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

---

## 📖 Learning Resources

### SDAIA Academy
- [SDAIA Academy Website](https://sdaia.gov.sa)
- [SDAIA GitHub Organization](https://github.com/SDAIAAcademy)

### Data Engineering
- [Delta Lake Documentation](https://docs.delta.io)
- [Apache Kafka Documentation](https://kafka.apache.org/documentation/)
- [Apache Airflow Documentation](https://airflow.apache.org/docs/)

### RAG & LLM
- [Anthropic Prompt Engineering Guide](https://docs.anthropic.com/prompt-engineering)
- [RAGAS Evaluation Framework](https://github.com/explodinggradients/ragas)
- [LangChain RAG Documentation](https://python.langchain.com/docs/use_cases/retrieval_augmented_generation/)

### Modern Data Engineering Patterns
- [Lakehouse Architecture](https://databricks.com/blog/2020/01/30/what-is-a-data-lakehouse.html)
- [Data Contracts](https://www.datacontractshub.com/)
- [Data Quality Frameworks](https://www.giskard.ai/)

---

## 📋 Evaluation Criteria

This project demonstrates mastery in:

- **Data Engineering**: Modern lakehouse architecture with quality gates
- **Data Processing**: Streaming, validation, and transformation
- **Search & Retrieval**: Hybrid search with intelligent reranking
- **AI Integration**: LLM integration and prompt engineering
- **Operations**: Orchestration, monitoring, and production-readiness
- **Code Quality**: Clean, documented, tested code
- **Communication**: Clear documentation and evidence

---

## 🔐 Security & Best Practices

- **Environment Variables**: Sensitive config via `.env` (never committed)
- **Logging**: Structured logs without sensitive data
- **Testing**: Comprehensive unit and integration tests
- **Documentation**: Clear, maintainable, well-commented code
- **Containerization**: Reproducible environments with Docker
- **Version Control**: Clean git history with meaningful commits

---

## 📞 Support

For questions or issues:
- **SDAIA Academy**: [Academy@sdaia.gov.sa](mailto:Academy@sdaia.gov.sa)
- **Repository Issues**: Open a GitHub issue
- **Discussions**: GitHub Discussions for questions

---

## 📄 License

This project is licensed under the **Apache License 2.0** - see the [LICENSE](LICENSE) file for details.

---

## 🙏 Acknowledgments

- **SDAIA Academy** for the comprehensive curriculum
- **Contributors** from the Modern Data Engineering program
- **Open Source Community** for excellent tools and frameworks

---

## 🎯 Program Completion

**Program**: Modern Data Engineering for Advanced AI Systems  
**Organization**: SDAIA Academy  
**Capstone Project**: Full RAG Application  
**Status**: ✅ Completed  

#SDAIAAcademy | [GitHub](https://github.com/SDAIAAcademy)

---

*Last Updated: September 2026 | SDAIA Academy*
